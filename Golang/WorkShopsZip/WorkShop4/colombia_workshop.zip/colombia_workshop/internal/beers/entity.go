package beers

// Beer estructura que muestra las variables para este workshop
type Beer struct {
	ID       int
	Name     string
	Brewery  string
	Country  string
	Price    string
	Currency string
}
