# Concurrency Quiz
This quiz tests your knowledge of concurrency in golang. The application in this directory panics.  Your job is to fix it
using only golang's built in concurrency tools so that all values in the map reach the target successfully.  Good luck!