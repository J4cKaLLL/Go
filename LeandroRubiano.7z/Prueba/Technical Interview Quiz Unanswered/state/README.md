# State
The state package currently provide an interface `UserStore` with an incomplete, implementation `userStore`.  Your job
is to complete the implementation.  A simple test suite has been provided to assist you in this process.  Once the tests 
pass your have completed your task.  Good Luck!

### You are NOT permitted to change the `state_test.go` in any way.