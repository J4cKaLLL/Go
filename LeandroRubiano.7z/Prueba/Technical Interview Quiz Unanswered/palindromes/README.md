#Palindromes
In this quiz you will implement the method Detect of the Palindromes interface.  Your implementation must include 
unit tests that prove it works.

### Definition
A palindrome is a word, phrase, or sentence that reads the same backward and forward regardless of punctuation, spacing,
and language, such as `bob`, `Race car`, `oir a rio`, and `Madam, I'm Adam`.